function Footer(){
    return (
        <div>
        <h1>Footer</h1>
        <p>This is the footer section </p>
        </div>
    )

}
export default Footer;
