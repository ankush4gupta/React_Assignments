function Header(){
    return (
        <div>
        <h1>Header</h1>
        <p>This is the header section </p>
        </div>
    )

}
export default Header;
